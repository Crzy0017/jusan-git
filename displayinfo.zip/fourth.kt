sealed class DataType {
    class DoubleType(val num: Double) : DataType()
    class UnitType() : DataType()

    fun Any.displayTypeInfo() {
        when (this) {
            is Double -> {
                println("это DoubleType со значением $this")
            }
            is Unit -> {
                println("это Unit")
            }
            is Int -> {
                println("Это Int")
            }
            is String -> {
                println("Это String")
            }
            else -> {
                println("тип у $this неизвестен")
            }
        }
    }
}