fun Int.pow(power: Int, l: (Int) -> Unit): () -> Unit {
    var res = 1
    for (i in 1..power) {
        res *= this
    }
    return { println("$res") }
}