fun Int.pow(power: Int): Int {
    var res = 1
    for (i in 1..power) {
        res *= this
    }
    return res
}
