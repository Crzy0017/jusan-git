fun Any.displayTypeInfo() {
    when (this) {
        is Int -> {
            println("Это Int")
        }
        is String -> {
            println("Это String")
        }
        else -> {
            println("тип у $this неизвестен")
        }
    }
}